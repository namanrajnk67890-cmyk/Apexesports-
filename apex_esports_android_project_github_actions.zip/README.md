# Apex Esports Android Project

Android WebView app for Apex Esports.

## GitHub Actions build

The repository includes `.github/workflows/android.yml`, which builds a debug APK and uploads it as a workflow artifact.

**Important:** the included `gradlew` is a placeholder because this project package did not contain a real Gradle wrapper. Before using GitHub Actions, generate a real Gradle wrapper with a compatible Gradle installation (`gradle wrapper`) or open the project in Android Studio and generate/sync the wrapper, then push the project to GitHub.

For a Play Store release, create a properly signed Android App Bundle (`.aab`) and keep signing credentials out of the repository.
